package com.example.mainactivity;

public class WalkData {

    private String date;
    private float Duration;
    private Integer steps;
    private float Distance;

    //



}
